# prodig
De online git voor PRODIG

Hierboven kun je bij Projects het kanban bord terugvinden met issues en wat de status is per issue,
bij issues hierboven kun je de uitgebreide status en comments van een issue terugvinden.